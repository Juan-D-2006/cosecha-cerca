import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";

export default async function Home() {
  const { profile } = await getSession();
  redirect(profile?.role === "farmer" ? "/panel" : "/catalogo");
}
